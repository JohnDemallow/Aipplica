#!/usr/bin/env python3
import sys
import time
import tkinter as tk
#from usbdrv import *
from pyftdi.spi import SpiController

ctrl = SpiController(2)
ctrl.configure('ftdi://ftdi:232h/0')
spi=ctrl.get_port(1)
spi.set_frequency(100E+3)
out=bytearray(2)

class GetSpectra(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        self.title("Clock")
        self.w = tk.Canvas(self, width=960, height=720, bg="black", relief= "sunken", border=10)
        self.w.create_line(0,0,0,0, fill="white", tags="spectra")
        self.w.pack()

        e = tk.Button(self,text="Quit", command=self.Quit)
        e.pack()

        self.final=[]
        self.sorted=[]
        self.cmd=0x19	# this is 0x0C with shl then +1
        self.offset=0x100
        #self.offset=0x180
        self.scale=1

        for i in range(1500): self.final.append(0)
        for base in range(0,1500,100):
            for start in range(base,base+4,1):
                for scan in range(start,start+100,4):
                    if (scan<1500): self.sorted.append(scan)

        self.update_spectra()

    def update_spectra(self):
        self.result=[]
        self.shape=[]
        #sendswdata(self.cmd)
        spi.write([0x00,self.cmd])
        for j in range(60):
            #fid=recvswdata()
            fid=spi.read(2).hex()
            #print(fid)
            time.sleep(120E-3)
            for k in range(25):
                #temp=recvswdata() 
                temp=spi.read(2).hex()
                self.result.append((int(temp,16)-self.offset))
                #self.result.append((temp))

        for i in range(1500):
            key=self.sorted[i]
            value=self.result[i]
            self.final[key]=value
        #print(self.final)

        for i in range(1500):
            self.shape.append(i*self.scale)
            self.shape.append(self.final[i])

        self.w.coords("spectra", self.shape)
        self.after(60, self.update_spectra)

    def Quit(self):
        self.after(60,self.destroy())

app = GetSpectra()
app.mainloop()

