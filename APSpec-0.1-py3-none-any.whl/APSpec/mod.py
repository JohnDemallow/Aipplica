import time
from pyftdi.spi import SpiController
from pyftdi.ftdi import Ftdi

class Spectrometer():

        def __init__(self):

            self.NUMPIX = 1500		# Number of photodiodes in the array
            self.PIXAFRAME = 50		# Read this many pix in a sub-frame
            self.NUMFRAMES = int(self.NUMPIX/self.PIXAFRAME)
            self.NREREAD =5		# Reread first 5 frames
            self.PIXSTEP = 15		# Read every nth pixel where n = pixstep
            self.STEPSIZE= self.PIXAFRAME*self.PIXSTEP
            self.INTCOUNT = 8191	# variable count hex 0x1FFF
            self.MINCOUNT = 620		# Min wait period is 614 ~ 4.5msec plus s/w overheads
            self.MAXCOUNT = 16383	# Max count hex 0x3FFF
            self.TWAIT = 25E-3		# added delay 20 milliseconds at 0x3FFF count
					# Total min-int-time will be 4.5m+20msec+5ms(6.67us*50*16)
				        # SPI Master should wait for at least this time before initiating spi.read
            self.TSCAN = 4.5E-3		# Minimum integrating time
            self.TXFER = 5.3E-3		# Minimum 50 word transfer time at 150KHz SPI clock
            self.TMRGN = 5.0E-3
            self.FSPICLK = 150E+3	# SPI Clock set to 150KHz

            self.ctrl = SpiController(2)
            self.ctrl.configure('ftdi://ftdi:232h/0')
            self.spi = self.ctrl.get_port(1)
            self.spi.set_frequency(self.FSPICLK)
            self.sorted=[]
            for base in range(0,self.NUMPIX,self.STEPSIZE):
                for start in range(base,base+self.PIXSTEP,1):
                    for scan in range(start,start+self.STEPSIZE,self.PIXSTEP):
                        if (scan<self.NUMPIX): self.sorted.append(scan)

        def GetSpectra(self):
            result=[]
            final=[]
            fidarray=[]
            #delay=self.TWAIT*self.INTCOUNT/self.MAXCOUNT+ self.TSCAN + self.TXFER + self.TMRGN
            delay=self.TWAIT
            for i in range(self.NUMPIX): final.append(0)
            cmd = 0x19				# 0x0C SHL + 1
            self.spi.write([0x00,cmd])
            a=self.spi.read(2)
            for j in range(self.NUMFRAMES):
                #fid=self.spi.read(2).hex()	# frame id for debugging only
                #fidarray.append(int(fid,16))	# frame id for debugging only
                time.sleep(delay)		# wait for integration time 120msec
                #for k in range(self.PIXAFRAME):
                #   temp=self.spi.read(2).hex()
                #   result.append((int(temp,16)))
                temp=self.spi.read(2*self.PIXAFRAME)
                for k in range(0,2*self.PIXAFRAME,2):
                    result.append(int(temp[k:k+2].hex(),16))

            for j in range(self.NREREAD):			# Reread of the first two frame
                time.sleep(delay)		# wait for integration time 120msec
                temp=self.spi.read(2*self.PIXAFRAME)
                for k in range(0,2*self.PIXAFRAME,2):
                    #if (j==0): result[int(k/2)]=int(temp[k:k+2].hex(),16) #overwrite the first frame
                    #if (j==1): result[int(self.PIXAFRAME+k/2)]=int(temp[k:k+2].hex(),16) #overwrite the second frame
                    result[int(j*self.PIXAFRAME+k/2)]=int(temp[k:k+2].hex(),16) #overwrite the previous frames

            for i in range(self.NUMPIX):
            	key=self.sorted[i]
            	value=result[i]
            	final[key]=value

            return final

        def GetFrame(self):
            result=[]
            delay=self.TWAIT
            cmd = 0x1D				# 0x0E SHL + 1
            self.spi.write([0x00,cmd])
            a=self.spi.read(2)
            time.sleep(delay)		# wait for integration time 120msec
            temp=self.spi.read(2*self.PIXAFRAME)
            for k in range(0,2*self.PIXAFRAME,2):
                result.append(int(temp[k:k+2].hex(),16))

            return result

        def Setinttime(self,num):			# user specifies integation time in sec maxm. 120 msec
            if (num <=0 or num >= 120E-3): num = 120E-3
            self.INTCOUNT = int(num*65535/0.120)	# 16 bit hex number INTCOUNT max = 0xFFFF, 65535
            self.TWAIT = num
            numh = (self.INTCOUNT & 0xff00) >> 8	# isolate msbyte
            numh =  numh & 0x7f				# msb = start bit = 0
            numl = (self.INTCOUNT & 0x00ff)		# 
            numl = numl | 0x01 				# this is the stop bit
            #print(hex(numh),hex(numl))			# for debug
            cmd = 0x15					# 0x0A SHL + 1
            #self.spi.write([0x00,cmd])
            #self.spi.read(2)				# Readback (& verify)
            #time.sleep(1E-3)				# wait for 20 msec before issuing the next command
            #self.spi.write([numh,numl])			# effectively we can write only 14 bits, start bit is 0 and stop bit 1
            #self.spi.read(2)				# Readback (& verify)

            return

        
        def CheckParams(self):			# report vid, pid
            a=str(Ftdi.list_devices()).split(',')
            for s  in  a:
                if ('vid' in s): vid=hex(int(s[s.index('=')+1:]))
                if ('pid' in s): pid=hex(int(s[s.index('=')+1:]))
                if ('description' in s): model=s[s.index('=')+1:]
            return vid,pid,model

 
