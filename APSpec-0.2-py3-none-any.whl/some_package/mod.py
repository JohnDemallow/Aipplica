def prime(num):
	num=int(num)
	primes_list=[2,3,5,7]
	if num<2: return []
	if num<3: return [2]
	if num<5: return [2,3]
	if num<7: return [2,3,5]
	if num==7: return [2,3,5,7]
	for i in range(9,num+1,2):
		for j in primes_list:
			if i%j == 0: break
		if j == primes_list[-1]: 
			primes_list.append(i)
	return primes_list

def GetSpectra():
        import time
        from pyftdi.spi import SpiController

        ctrl = SpiController(2)
        ctrl.configure('ftdi://ftdi:232h/0')
        spi=ctrl.get_port(1)
        spi.set_frequency(100E+3)
        out=bytearray(2)

        final=[]
        sorted=[]
        result=[]
        shape=[]

        cmd=0x19	# this is 0x0C with shl then +1

        for i in range(1500): final.append(0)
        for base in range(0,1500,100):
            for start in range(base,base+4,1):
                for scan in range(start,start+100,4):
                    if (scan<1500): sorted.append(scan)

        spi.write([0x00,cmd])
        for j in range(60):
            fid=spi.read(2).hex()
            time.sleep(120E-3)		#wait for 120msec
            for k in range(25):
                temp=spi.read(2).hex()
                result.append((int(temp,16)))

        for i in range(1500):
            key=sorted[i]
            value=result[i]
            final[key]=value

        for i in range(1500):
            shape.append(i)
            shape.append(final[i])

        return final

