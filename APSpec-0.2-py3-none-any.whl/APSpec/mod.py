# Copyright © 2000-2022 Aipplica Systems Pte Ltd
# 
# 
# THIS SOFTWARE IS PROVIDED BY AIPPLICA SYSTEMS PTE LIMITED ``AS IS'' AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AIPPLICA SYSTEMS PTE INTERNATIONAL LIMITED
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.

import time
import struct
from pyftdi.spi import SpiController
from pyftdi.ftdi import Ftdi

class Spectrometer():

        def __init__(self):

            self.NUMPIX = 1500		# Number of photodiodes in the array
            self.PIXASBLK = 50		# Read this many pix in a sub-block
            self.NUMSBLKS = int(self.NUMPIX/self.PIXASBLK) # Number of sub-blocks
            self.NREREAD =5		# Reread first 5 sub blocks
            self.PIXSTEP = 15		# Read every nth pixel where n = pixstep
            self.STEPSIZE= self.PIXASBLK*self.PIXSTEP # This is the big step.
            self.TWAIT = 2.5E-3		# Min delay before data can be read
            self.TSCAN = 9.4E-3		# Minimum integrating time
            self.FSPICLK = 100E+3	# SPI Clock set to 100KHz

            self.ctrl = SpiController(2)
            self.ctrl.configure('ftdi://ftdi:232h/0')
            self.spi = self.ctrl.get_port(1)
            self.spi.set_frequency(self.FSPICLK)
            self.scanpat=[]		# pixels are scanned in this pattern
            for base in range(0,self.NUMPIX,self.STEPSIZE):
                for start in range(base,base+self.PIXSTEP,1):
                    for scan in range(start,start+self.STEPSIZE,self.PIXSTEP):
                        if (scan<self.NUMPIX): self.scanpat.append(scan)

        def GetSpectra(self):
            result=[]
            final=[]
            fidarray=[]
            delay=self.TSCAN 
            for i in range(self.NUMPIX): final.append(0)
            self.spi.write([0x00,0x19])		# 0x0C SHL + 1
            a=self.spi.read(2)
            time.sleep(self.TWAIT)		# wait for min delay time 2.5msec before first read
            for j in range(self.NUMSBLKS):
                temp=self.spi.read(2*self.PIXASBLK)
                time.sleep(delay)		# wait for integration delay time 
                for k in range(0,2*self.PIXASBLK,2):
                    result.append(int(temp[k:k+2].hex(),16))

            for j in range(self.NREREAD):			# Reread of the first NREREAD frames
                temp=self.spi.read(2*self.PIXASBLK)
                time.sleep(delay)		# wait for min delay time
                for k in range(0,2*self.PIXASBLK,2):
                    result[int(j*self.PIXASBLK+k/2)]=int(temp[k:k+2].hex(),16) #overwrite the previous frames

            for i in range(self.NUMPIX):
            	key=self.scanpat[i]
            	value=result[i]
            	final[key]=value

            return final

        def SetIntTime(self,delayms):		# delayms is delay in msec
            if type(delayms) == int or type(delayms) == float:
               pass
            else:
                delayms=9.4			# Default value 9.4msec
            if (delayms>262): delayms = 262     # Max delay 262msec
            if (delayms<2.5): delayms = 9.4     # Min delay 9.4msec
            self.TSCAN = delayms/1000		# update min integration time
            num = int(1000*delayms/4)		# scale to counter value 1 count ~ 4usec
            self.spi.write([0x00,0x15])		# Command code 0A SHL + 1
            time.sleep(0.1E-3)
            a=self.spi.read(2)

            bc =0x0
            bh=num.to_bytes(2,"little")[1]
            if (bh>0x80): bc = 0x01;
            bh <<=1; bh +=1;
            bh &= 0xff;
            self.spi.write([bc,bh])    		#write upper byte

            bc =0x0
            bl=num.to_bytes(2,"little")[0]
            if (bl>0x80): bc = 0x01;
            bl <<=1; bl +=1;
            bl &= 0xff;
            self.spi.write([bc,bl])    		#write lower byte

            time.sleep(0.1E-3)

            a=self.spi.read(2)

        def ReadCal(self):
            Coeff=[]
            self.spi.write([0x00,0x0D])		# shl command code and add 1
            time.sleep(0.1E-3)
            a=self.spi.read(2)
            if ((a[0]==0x00) & (a[1]==0x06)): 	# read back command and verify
                time.sleep(1E-3)
                a=self.spi.read(100)
                NumCalCoeff =int(int(a[1:2].hex(),16)/4)
                for i in range(NumCalCoeff):
                  j = 8*i+3
                  bcomb=a[j:j+1]+a[j+2:j+3]+a[j+4:j+5]+a[j+6:j+7]
                  c=struct.unpack("f",bcomb)
                  Coeff.append(c[0])
                return  (Coeff)
            else: 
              print("Command Echoback fail",(a).hex())

        def WriteCal(self,*argv):
            ncalb = 0
            for arg in argv:
              if type(arg) == int or type(arg) == float:
                a=arg
              else: 
                a=0				#Non number arguments are not stored
              ba=bytearray(struct.pack("f",a))
              ncalb +=4				# +=len(ba) 4 bytes per coeff.

            self.spi.write([0x00,0x9]);
            time.sleep(0.1E-3)
            a=self.spi.read(2)

            if ((a[0]==0x00) & (a[1]==0x04)): 	# read back command and verify

              ncalb <<=1; ncalb +=1		# shl ncal by 1 and set stop bit
              self.spi.write([0x00,ncalb])		

              for arg in argv:
                if type(arg) == int or type(arg) == float:
                  a=arg
                else: 
                  a=0			 	# Non numerical arguments are not stored
                ba=bytearray(struct.pack("f",a))
                for i in range(4):
                  bl = ba[i]
                  bl <<=1; bl +=1
                  if ba[i]<128:
                    self.spi.write([0x00,bl])		# shl  num of words and add 1
                  else:
                    bl &= 0xff
                    self.spi.write([0x01,bl])		# shl  num of words and add 1

            else:
                print("Command Echoback fail",(a).hex())
        
        def CheckParams(self):			# report vid, pid
            a=str(Ftdi.list_devices()).split(',')
            for s  in  a:
                if ('vid' in s): vid=hex(int(s[s.index('=')+1:]))
                if ('pid' in s): pid=hex(int(s[s.index('=')+1:]))
                if ('description' in s): model=s[s.index('=')+1:]
            return vid,pid,model

        def ReadId(self):			# report mcuid, sensorid, hardwareid, firmware revision
            self.spi.write([0x00,0x05]);		#
            time.sleep(0.1E-3)
            a=self.spi.read(2)			# MCUID,SENSID, BDID, FWREV
            time.sleep(0.1E-3)
            a=self.spi.read(2+2+2+2)		# MCUID,SENSID, BDID, FWREV
            mcuid=hex(a[1]); sensid=hex(a[3]); hwid=hex(a[5]); fwrev=hex(a[7]);
            return mcuid, sensid, hwid, fwrev

